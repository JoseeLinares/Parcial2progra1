﻿namespace WinFormsApp1
{
    internal class DatabaseManager
    {
        public DatabaseManager()
        {
        }
    }
}